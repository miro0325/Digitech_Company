# ThryEditor
General Unity Shader Inspector/Editor with focus on vrchat shaders

# [Discord Server for all my Assets](https://discord.thryrallo.de/)
